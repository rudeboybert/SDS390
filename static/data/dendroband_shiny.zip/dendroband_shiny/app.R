#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#


library(shiny)
library(tidyverse)

# Set all non-interactive elements ---------------------------------------------
# Load data
dendroband_data <- read_csv("https://rudeboybert.github.io/SDS390/static/data/observed_dbh_vs_doy.csv")

# Set "base plot" of points that won't change
base_plot <- ggplot() +
    geom_point(data = dendroband_data, mapping = aes(x = doy, y = dbh)) +
    labs(x = "day of year", y = "dbh")

# Define the generalized logistic function. Note the params input has to be a
# vector of length 5 in the correct order:
lg5 <- function(params, doy) {
    # Get 5 parameter values
    L <- params[1]
    K <- params[2]
    doy.ip <- params[3]
    r <- params[4]
    theta <- params[5]

    # For specified 5 parameters and x = doy, compute y = dbh
    dbh <- L + ((K - L) / (1 + 1/theta * exp(-(r * (doy - doy.ip) / theta)) ^ theta))
    return(dbh)
}


# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("Fit a 5-parameter generalized logistic curve to dendroband data"),

    # Sidebar with a slider input for number of bins
    sidebarLayout(
        sidebarPanel(
            sliderInput("K",
                        "K: lower aysymptote",
                        min = 10,
                        max = 20,
                        value = 12),
            sliderInput("L",
                        "L: upper asymptote",
                        min = 10,
                        max = 20,
                        value = 14),
            sliderInput("doy.ip",
                        "doy.ip: day of year inflection point",
                        min = 1,
                        max = 365,
                        value = 100),
            sliderInput("r",
                        "r: slope of curve at inflection point:",
                        min = 0,
                        max = 1,
                        value = 0.8),
            sliderInput("theta",
                        "theta: symmetry parameter:",
                        min = 0.5,
                        max = 2,
                        value = 1)

        ),

        # Show a plot of the generated distribution
        mainPanel(
            plotOutput("distPlot")
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {

    output$distPlot <- renderPlot({
        # Get parameter values
        K <- input$K
        L <- input$L
        doy.ip <- input$doy.ip
        r <- input$r
        theta <- input$theta
        params <- c(K, L, doy.ip, r, theta)

        # Add interactive curve to base_plot
        base_plot +
            stat_function(fun = lg5, args = list(params = params), col = "red", n = 500)

    })
}

# Run the application
shinyApp(ui = ui, server = server)
